// Initialize Mermaid
mermaid.initialize({ startOnLoad: false, theme: 'default' });

// Register ChartDataLabels plugin
if (typeof ChartDataLabels !== 'undefined') {
    Chart.register(ChartDataLabels);
}

// Define mode aliases for syntax highlighting
CodeMirror.defineMode("chart", function(config) {
    return CodeMirror.getMode(config, "javascript");
});
CodeMirror.defineMode("mermaid", function(config) {
    return CodeMirror.getMode(config, "text/plain");
});
CodeMirror.defineMode("desmos", function(config) {
    return CodeMirror.getMode(config, "javascript");
});
CodeMirror.defineMode("math", function(config) {
    return CodeMirror.getMode(config, "stex");
});

// Initialize CodeMirror
const cmEditor = CodeMirror.fromTextArea(document.getElementById('editor'), {
    mode: 'markdown',
    theme: 'dracula',
    lineNumbers: true,
    lineWrapping: true,
    autoCloseBrackets: true,
    styleActiveLine: true,
    extraKeys: {"Enter": "newlineAndIndentContinueMarkdownList"}
});

const preview = document.getElementById('preview');

// Debounce function to prevent excessive rendering
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Main render function
function render() {
    const markdown = cmEditor.getValue();
    
    const renderer = new marked.Renderer();
    const originalCodeRenderer = renderer.code.bind(renderer);
    
    renderer.code = (code, language) => {
        const lang = (language || '').trim().toLowerCase();
        
        if (lang === 'chart') {
            return `<div class="chart-placeholder" data-config="${encodeURIComponent(code)}"></div>`;
        }
        
        if (lang === 'mermaid') {
            return `<div class="mermaid">${code}</div>`;
        }
        
        if (lang === 'desmos') {
            return `<div class="desmos-placeholder" data-content="${encodeURIComponent(code)}"></div>`;
        }
        
        return originalCodeRenderer(code, language);
    };

    // Render HTML
    try {
        preview.innerHTML = marked.parse(markdown, {
            renderer: renderer,
            breaks: true,
            gfm: true
        });
    } catch (e) {
        console.error("Markdown parsing error:", e);
        preview.innerHTML = `<p style="color:red">Error parsing markdown: ${e.message}</p>`;
        return;
    }

    // 2. Post-process: Render Charts
    const chartPlaceholders = preview.querySelectorAll('.chart-placeholder');
    chartPlaceholders.forEach((el, index) => {
        try {
            const configStr = decodeURIComponent(el.getAttribute('data-config'));
            
            // Use Function constructor to allow relaxed JSON (e.g. comments, trailing commas)
            // Wrap in parentheses to ensure it's treated as an expression
            const config = new Function('return (' + configStr + ')')();
            
            const canvasContainer = document.createElement('div');
            canvasContainer.className = 'chart-container';
            const canvas = document.createElement('canvas');
            canvas.id = `chart-${index}`;
            canvasContainer.appendChild(canvas);
            
            el.replaceWith(canvasContainer);
            
            if (typeof Chart !== 'undefined') {
                new Chart(canvas, config);
            } else {
                canvasContainer.innerHTML = '<p style="color:red">Chart.js library not loaded.</p>';
            }
        } catch (e) {
            console.error("Chart rendering error:", e);
            el.innerHTML = `<pre style="color:red; background:#ffebee; padding:10px;">Error rendering chart:\n${e.message}</pre>`;
        }
    });

    // 3. Post-process: Render Mermaid
    // Mermaid looks for .mermaid class. We need to tell it to run on the new content.
    mermaid.run({
        nodes: preview.querySelectorAll('.mermaid')
    });

    // 4. Post-process: Render Desmos
    const desmosPlaceholders = preview.querySelectorAll('.desmos-placeholder');
    desmosPlaceholders.forEach((el, index) => {
        try {
            const content = decodeURIComponent(el.getAttribute('data-content'));
            let lines = content.split('\n');
            
            // Parse config
            let config = {};
            let expressions = [];
            
            // Check for config comment
            // Looking for //config: {...}
            // We need to handle nested braces for JSON object
            const fullText = lines.join('\n');
            const configStartMarker = '//config:';
            const configStartIndex = fullText.indexOf(configStartMarker);
            
            if (configStartIndex !== -1) {
                let braceCount = 0;
                let jsonStartIndex = -1;
                let jsonEndIndex = -1;
                
                // Find start of JSON
                for (let i = configStartIndex + configStartMarker.length; i < fullText.length; i++) {
                    if (fullText[i] === '{') {
                        jsonStartIndex = i;
                        braceCount = 1;
                        break;
                    }
                }
                
                if (jsonStartIndex !== -1) {
                    // Find end of JSON
                    for (let i = jsonStartIndex + 1; i < fullText.length; i++) {
                        if (fullText[i] === '{') braceCount++;
                        if (fullText[i] === '}') braceCount--;
                        
                        if (braceCount === 0) {
                            jsonEndIndex = i + 1;
                            break;
                        }
                    }
                }
                
                if (jsonEndIndex !== -1) {
                    const jsonStr = fullText.substring(jsonStartIndex, jsonEndIndex);
                    try {
                        config = JSON.parse(jsonStr);
                        // Remove the config block from the text to process expressions
                        // We replace it with newlines to keep line numbers if needed, or just empty string
                        // We also need to remove the //config: marker
                        const beforeConfig = fullText.substring(0, configStartIndex);
                        const afterConfig = fullText.substring(jsonEndIndex);
                        // Reconstruct lines without config
                        const remainingText = beforeConfig + afterConfig;
                        // We need to re-split, but we should be careful about the //config: line itself
                        // The configStartIndex points to //config:
                        // So beforeConfig ends right before it.
                        
                        // Let's just use the remaining text for expressions
                        lines = remainingText.split('\n');
                        
                    } catch (e) {
                        console.error("Invalid Desmos config JSON", e);
                    }
                }
            }

            // Filter out config lines and empty lines for expressions
            // A simple way is to just pass everything that isn't a comment to setExpression
            // But we need to be careful.
            
            const container = document.createElement('div');
            container.className = 'desmos-container';
            container.id = `desmos-${index}`;
            el.replaceWith(container);

            if (typeof Desmos !== 'undefined') {
                const calculator = Desmos.GraphingCalculator(container, {
                    keypad: false,
                    expressions: config.expressions !== false,
                    settingsMenu: false,
                    ...config // Apply other config options like lockViewport
                });

                // Set bounds if provided
                if (config.bounds) {
                    calculator.setMathBounds({
                        left: config.bounds.x[0],
                        right: config.bounds.x[1],
                        bottom: config.bounds.y[0],
                        top: config.bounds.y[1]
                    });
                }

                // Add expressions
                // We need to parse the lines. 
                // Lines starting with // are comments (except config).
                // We treat each non-empty line as an expression.
                
                let exprIndex = 0;
                lines.forEach(line => {
                    const trimmed = line.trim();
                    if (!trimmed || trimmed.startsWith('//')) return;
                    
                    // Check if it's a slider definition like a=1
                    // Desmos handles this automatically if passed as latex
                    
                    calculator.setExpression({ id: `expr-${exprIndex++}`, latex: trimmed });
                });
            } else {
                container.innerHTML = '<p style="color:red">Desmos API not loaded.</p>';
            }

        } catch (e) {
            el.innerHTML = `<p style="color:red">Error rendering Desmos: ${e.message}</p>`;
        }
    });

    // 5. Post-process: Render Math (KaTeX)
    renderMathInElement(preview, {
        delimiters: [
            {left: '$$', right: '$$', display: true},
            {left: '$', right: '$', display: false}
        ],
        throwOnError: false
    });
}

// Event Listeners
cmEditor.on('change', debounce(render, 500));

// Initial Render
render();


// Templates
const templates = {
    barChart: `\`\`\`chart
{
    "type": "bar",
    "data": {
        "labels": ["Jan", "Feb", "Mar"],
        "datasets": [{
            "label": "Sales",
            "data": [10, 20, 30],
            "backgroundColor": ["rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)"]
        }]
    }
}
\`\`\``,
    lineChart: `\`\`\`chart
{
    "type": "line",
    "data": {
        "labels": ["Week 1", "Week 2", "Week 3"],
        "datasets": [{
            "label": "Progress",
            "data": [10, 25, 45],
            "borderColor": "rgb(75, 192, 192)",
            "tension": 0.1
        }]
    }
}
\`\`\``,
    pieChart: `\`\`\`chart
{
    "type": "pie",
    "data": {
        "labels": ["Red", "Blue", "Yellow"],
        "datasets": [{
            "data": [300, 50, 100],
            "backgroundColor": ["rgb(255, 99, 132)", "rgb(54, 162, 235)", "rgb(255, 205, 86)"]
        }]
    }
}
\`\`\``,
    doughnutChart: `\`\`\`chart
{
    "type": "doughnut",
    "data": {
        "labels": ["A", "B", "C"],
        "datasets": [{
            "data": [30, 20, 25],
            "backgroundColor": ["rgb(255, 99, 132)", "rgb(54, 162, 235)", "rgb(255, 205, 86)"]
        }]
    }
}
\`\`\``,
    flowchart: `\`\`\`mermaid
graph TD
    A[Start] --> B{Is it working?}
    B -->|Yes| C[Great!]
    B -->|No| D[Debug]
    D --> B
\`\`\``,
    sequence: `\`\`\`mermaid
sequenceDiagram
    Alice->>John: Hello John, how are you?
    John-->>Alice: Great!
\`\`\``,
    classDiagram: `\`\`\`mermaid
classDiagram
    class Animal {
        +String name
        +void eat()
    }
    class Duck {
        +void quack()
    }
    Animal <|-- Duck
\`\`\``,
    stateDiagram: `\`\`\`mermaid
stateDiagram-v2
    [*] --> Still
    Still --> [*]
    Still --> Moving
    Moving --> Still
    Moving --> Crash
    Crash --> [*]
\`\`\``,
    gantt: `\`\`\`mermaid
gantt
    title A Gantt Diagram
    dateFormat  YYYY-MM-DD
    section Section
    A task           :a1, 2014-01-01, 30d
    Another task     :after a1  , 20d
\`\`\``,
    erDiagram: `\`\`\`mermaid
erDiagram
    CUSTOMER ||--o{ ORDER : places
    ORDER ||--|{ LINE-ITEM : contains
    CUSTOMER }|..|{ DELIVERY-ADDRESS : uses
\`\`\``,
    journey: `\`\`\`mermaid
journey
    title My working day
    section Go to work
      Make tea: 5: Me
      Go upstairs: 3: Me
      Do work: 1: Me, Cat
    section Go home
      Go downstairs: 5: Me
      Sit down: 5: Me
\`\`\``,
    inlineMath: `$E = mc^2$`,
    displayMath: `$$x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}$$`,
    desmos: `\`\`\`desmos
//config: {
  "bounds": {"x": [-10, 10], "y": [-10, 10]},
  "grid": true
}
y=x^2
y=sin(x)
\`\`\``,
    markscheme: `<details>
<summary>Markscheme</summary>

---

Answer: 42

</details>`
};

// Templates Data
const templateCategories = {
    charts: [
        { id: 'barChart', label: 'Bar Chart', code: templates.barChart },
        { id: 'lineChart', label: 'Line Chart', code: templates.lineChart },
        { id: 'pieChart', label: 'Pie Chart', code: templates.pieChart },
        { id: 'doughnutChart', label: 'Doughnut Chart', code: templates.doughnutChart }
    ],
    mermaid: [
        { id: 'flowchart', label: 'Flowchart', code: templates.flowchart },
        { id: 'sequence', label: 'Sequence Diagram', code: templates.sequence },
        { id: 'classDiagram', label: 'Class Diagram', code: templates.classDiagram },
        { id: 'stateDiagram', label: 'State Diagram', code: templates.stateDiagram },
        { id: 'gantt', label: 'Gantt Chart', code: templates.gantt },
        { id: 'erDiagram', label: 'ER Diagram', code: templates.erDiagram },
        { id: 'journey', label: 'User Journey', code: templates.journey }
    ],
    math: [
        { id: 'inlineMath', label: 'Inline Math', code: templates.inlineMath },
        { id: 'displayMath', label: 'Display Math', code: templates.displayMath },
        { id: 'desmos', label: 'Desmos Graph', code: templates.desmos }
    ],
    chemistry: [
        { id: 'chemEq', label: 'Chemical Equation', code: '$\\ce{H2O}$' },
        { id: 'chemReaction', label: 'Reaction', code: '$\\ce{A + B -> C}$' },
        { id: 'chemIsotope', label: 'Isotope', code: '$\\ce{^{227}_{90}Th+}$' }
    ],
    misc: [
        { id: 'markscheme', label: 'Markscheme', code: templates.markscheme }
    ]
};

// Template Modal Logic
const templateModal = document.getElementById('template-modal');
const templateGrid = document.getElementById('template-grid');
const templateModalTitle = document.getElementById('template-modal-title');

function openTemplateModal(category) {
    // Intercept Math and Chemistry to open Builder if needed
    // But user might want templates too. Let's keep templates for now, 
    // and maybe add a "Open Builder" button in the modal or handle specific items.
    // Actually, user said "after picking inline vs block it should open another ui".
    // So we modify insertTemplateCode or the click handler in the modal.
    
    templateModal.style.display = 'block';
    templateModalTitle.textContent = `Insert ${category.charAt(0).toUpperCase() + category.slice(1)}`;
    templateGrid.innerHTML = ''; // Clear previous

    const items = templateCategories[category];
    if (!items) return;

    items.forEach(item => {
        const card = document.createElement('div');
        card.className = 'template-card';
        card.onclick = () => {
            if (item.id === 'inlineMath' || item.id === 'displayMath' || category === 'chemistry') {
                openMathBuilder(item.id, item.code);
            } else {
                insertTemplateCode(item.code);
            }
            closeTemplateModal();
        };

        const preview = document.createElement('div');
        preview.className = 'template-preview';
        preview.id = `preview-${item.id}`;

        const title = document.createElement('div');
        title.className = 'template-title';
        title.textContent = item.label;

        card.appendChild(preview);
        card.appendChild(title);
        templateGrid.appendChild(card);

        // Render Preview
        setTimeout(() => renderPreview(item, preview), 0);
    });
}

function closeTemplateModal() {
    templateModal.style.display = 'none';
}

function insertTemplate(key) {
    if (templates[key]) {
        insertTemplateCode(templates[key]);
    }
}

function insertTemplateCode(code) {
    const doc = cmEditor.getDoc();
    const cursor = doc.getCursor();
    const line = doc.getLine(cursor.line);
    
    // Add newlines if not on an empty line
    const textToInsert = (line.length > 0 ? '\n\n' : '') + code + '\n\n';
    
    doc.replaceRange(textToInsert, cursor);
    
    render();
    cmEditor.focus();
}

function renderPreview(item, container) {
    // Extract code content (remove markdown fences)
    let code = item.code;
    let type = '';

    if (code.startsWith('```chart')) {
        type = 'chart';
        code = code.replace(/```chart\n|```/g, '');
    } else if (code.startsWith('```mermaid')) {
        type = 'mermaid';
        code = code.replace(/```mermaid\n|```/g, '');
    } else if (code.startsWith('```desmos')) {
        type = 'desmos';
        // Desmos preview is hard to render multiple instances efficiently in this simple setup
        // We'll show a placeholder icon or text
        container.innerHTML = '<span class="material-icons" style="font-size: 48px; color: #ccc;">functions</span>';
        return;
    } else if (code.startsWith('$')) {
        type = 'math';
        // Keep the $ for katex
    } else {
        // Misc or others
        container.innerHTML = '<span class="material-icons" style="font-size: 48px; color: #ccc;">description</span>';
        return;
    }

    try {
        if (type === 'chart') {
            const canvas = document.createElement('canvas');
            container.appendChild(canvas);
            // Use Function constructor for relaxed JSON
            const config = new Function('return (' + code + ')')();
            // Disable animation for previews
            if (config.options) {
                config.options.animation = false;
                config.options.responsive = true;
                config.options.maintainAspectRatio = false;
            } else {
                config.options = { animation: false, responsive: true, maintainAspectRatio: false };
            }
            new Chart(canvas, config);
        } else if (type === 'mermaid') {
            // Mermaid render
            // We need a unique ID
            const id = 'mermaid-' + Math.random().toString(36).substr(2, 9);
            container.innerHTML = `<div class="mermaid" id="${id}">${code}</div>`;
            mermaid.run({ nodes: [container.querySelector('.mermaid')] });
        } else if (type === 'math') {
            // KaTeX
            const mathCode = code.replace(/\$\$/g, '').replace(/\$/g, '');
            const isDisplay = code.startsWith('$$');
            katex.render(mathCode, container, {
                throwOnError: false,
                displayMode: isDisplay
            });
        }
    } catch (e) {
        console.error("Preview render error", e);
        container.innerHTML = '<span style="color:red; font-size:12px">Preview Error</span>';
    }
}

// Text Formatting
function formatText(type) {
    const doc = cmEditor.getDoc();
    const selection = doc.getSelection();
    const cursor = doc.getCursor();
    let replacement = '';
    let cursorOffset = 0; // Not strictly needed with CodeMirror's setSelection but good for logic

    switch (type) {
        case 'bold':
            replacement = `**${selection || 'Bold Text'}**`;
            break;
        case 'italic':
            replacement = `*${selection || 'Italic Text'}*`;
            break;
        case 'strikethrough':
            replacement = `~~${selection || 'Strikethrough Text'}~~`;
            break;
        case 'h1':
            replacement = `# ${selection || 'Heading 1'}`;
            break;
        case 'h2':
            replacement = `## ${selection || 'Heading 2'}`;
            break;
        case 'h3':
            replacement = `### ${selection || 'Heading 3'}`;
            break;
        case 'ul':
            replacement = `- ${selection || 'List Item'}`;
            break;
        case 'ol':
            replacement = `1. ${selection || 'List Item'}`;
            break;
        case 'task':
            replacement = `- [ ] ${selection || 'Task Item'}`;
            break;
        case 'quote':
            replacement = `> ${selection || 'Quote'}`;
            break;
        case 'code':
            if (selection.includes('\n')) {
                replacement = `\`\`\`\n${selection}\n\`\`\``;
            } else {
                replacement = `\`${selection || 'code'}\``;
            }
            break;
        case 'link':
            replacement = `[${selection || 'Link Text'}](url)`;
            break;
        case 'image':
            replacement = `![${selection || 'Alt Text'}](image-url)`;
            break;
        case 'table':
            // Handled by modal now, but keep basic fallback or remove
            openTableModal();
            return;
    }

    doc.replaceSelection(replacement);
    
    // If no selection was made, we might want to select the placeholder text
    // This is a bit more complex with CodeMirror but basic replacement works fine.
    
    render();
    cmEditor.focus();
}

// Table Modal Logic
const tableModal = document.getElementById('table-modal');

// Table Grid Logic
const tableGridSelector = document.getElementById('table-grid-selector');
const tableGridLabel = document.getElementById('table-grid-label');
let selectedRows = 1;
let selectedCols = 1;

function initTableGrid() {
    tableGridSelector.innerHTML = '';
    for (let r = 1; r <= 10; r++) {
        for (let c = 1; c <= 10; c++) {
            const cell = document.createElement('div');
            cell.className = 'grid-cell';
            cell.dataset.row = r;
            cell.dataset.col = c;
            
            cell.addEventListener('mouseover', () => highlightGrid(r, c));
            cell.addEventListener('click', () => insertGridTable(r, c));
            
            tableGridSelector.appendChild(cell);
        }
    }
}

function highlightGrid(rows, cols) {
    selectedRows = rows;
    selectedCols = cols;
    tableGridLabel.textContent = `${rows} x ${cols}`;
    
    const cells = tableGridSelector.children;
    for (let cell of cells) {
        const r = parseInt(cell.dataset.row);
        const c = parseInt(cell.dataset.col);
        if (r <= rows && c <= cols) {
            cell.classList.add('active');
        } else {
            cell.classList.remove('active');
        }
    }
}

function insertGridTable(rows, cols) {
    let tableMD = '\n';
    // Header
    tableMD += '| ' + Array(cols).fill('Header').join(' | ') + ' |\n';
    // Separator
    tableMD += '| ' + Array(cols).fill('---').join(' | ') + ' |\n';
    // Rows
    for (let i = 0; i < rows; i++) {
        tableMD += '| ' + Array(cols).fill('Cell').join(' | ') + ' |\n';
    }
    tableMD += '\n';
    
    const doc = cmEditor.getDoc();
    const cursor = doc.getCursor();
    doc.replaceRange(tableMD, cursor);
    
    closeTableModal();
    render();
    cmEditor.focus();
}

function closeTableModal() {
    document.getElementById('table-modal').style.display = 'none';
}

// Override openTableModal to init grid
const originalOpenTableModal = window.openTableModal; // If it existed globally
// We'll just redefine it since we replaced the HTML
function openTableModal() {
    document.getElementById('table-modal').style.display = 'block';
    initTableGrid();
    highlightGrid(1, 1);
}

// Math Builder Logic
const mathModal = document.getElementById('math-modal');
const mathInput = document.getElementById('math-input');
const mathPreview = document.getElementById('math-preview');
const mathSymbolsGrid = document.getElementById('math-symbols-grid');
const mathBlockCheck = document.getElementById('math-block-check');
const mathChemCheck = document.getElementById('math-chem-check');
const periodicTableContainer = document.getElementById('periodic-table-container');
const periodicTableGrid = document.getElementById('periodic-table-grid');
let currentMathMode = 'inline'; // inline or display
let isChemMode = false;

const mathSymbols = {
    common: [
        { label: '+', code: '+' }, { label: '-', code: '-' }, { label: '=', code: '=' },
        { label: '×', code: '\\times' }, { label: '÷', code: '\\div' },
        { label: '±', code: '\\pm' }, { label: '\\sqrt{}', code: '\\sqrt{}', display: '\\sqrt{\\Box}' },
        { label: 'x²', code: '^2', display: 'x^2' }, { label: 'x_n', code: '_{n}', display: 'x_n' },
        { label: 'frac', code: '\\frac{a}{b}', display: '\\frac{a}{b}' }
    ],
    calculus: [
        { label: 'd/dx', code: '\\frac{d}{dx}', display: '\\frac{d}{dx}' }, 
        { label: '∂/∂x', code: '\\frac{\\partial}{\\partial x}', display: '\\frac{\\partial}{\\partial x}' },
        { label: '∫', code: '\\int' }, 
        { label: '∫ab', code: '\\int_{a}^{b}', display: '\\int_{a}^{b}' },
        { label: '∬', code: '\\iint' }, { label: '∮', code: '\\oint' },
        { label: 'lim', code: '\\lim_{x \\to \\infty}', display: '\\lim_{x \\to \\infty}' }, 
        { label: 'f\'', code: 'f\'(x)', display: 'f\'(x)' }
    ],
    greek: [
        { label: 'α', code: '\\alpha' }, { label: 'β', code: '\\beta' }, { label: 'γ', code: '\\gamma' },
        { label: 'δ', code: '\\delta' }, { label: 'θ', code: '\\theta' }, { label: 'λ', code: '\\lambda' },
        { label: 'π', code: '\\pi' }, { label: 'σ', code: '\\sigma' }, { label: 'ω', code: '\\omega' },
        { label: 'Δ', code: '\\Delta' }, { label: 'Σ', code: '\\Sigma' }, { label: 'Ω', code: '\\Omega' }
    ],
    operators: [
        { label: '∑', code: '\\sum' }, { label: '∫', code: '\\int' }, { label: '∏', code: '\\prod' },
        { label: 'lim', code: '\\lim' }, { label: '∞', code: '\\infty' },
        { label: '∂', code: '\\partial' }, { label: '∇', code: '\\nabla' }
    ],
    relations: [
        { label: '≠', code: '\\neq' }, { label: '≈', code: '\\approx' },
        { label: '≤', code: '\\leq' }, { label: '≥', code: '\\geq' },
        { label: '∈', code: '\\in' }, { label: '∉', code: '\\notin' },
        { label: '⊂', code: '\\subset' }, { label: '⊃', code: '\\supset' }
    ],
    chemistry: [
        { label: '→', code: '->', display: '\\rightarrow' }, 
        { label: '⇌', code: '<=>', display: '\\rightleftharpoons' },
        { label: '↑', code: '^', display: '\\uparrow' }, 
        { label: '↓', code: 'v', display: '\\downarrow' },
        { label: 'H₂O', code: 'H2O', display: '\\text{H}_2\\text{O}' }, 
        { label: 'CO₂', code: 'CO2', display: '\\text{CO}_2' },
        { label: 'Isotope', code: '^{A}_{Z}X', display: '^{A}_{Z}X' },
        { label: '+', code: '+' }, { label: '-', code: '-' }
    ]
};

// Periodic Table Data (Expanded with Categories)
const periodicTableData = [
    // Row 1
    { n: 1, s: 'H', name: 'Hydrogen', c: 'nonmetal' }, ...Array(16).fill({ n: 0 }), { n: 2, s: 'He', name: 'Helium', c: 'noble' },
    // Row 2
    { n: 3, s: 'Li', name: 'Lithium', c: 'alkali' }, { n: 4, s: 'Be', name: 'Beryllium', c: 'alkaline-earth' }, ...Array(10).fill({ n: 0 }), { n: 5, s: 'B', name: 'Boron', c: 'metalloid' }, { n: 6, s: 'C', name: 'Carbon', c: 'nonmetal' }, { n: 7, s: 'N', name: 'Nitrogen', c: 'nonmetal' }, { n: 8, s: 'O', name: 'Oxygen', c: 'nonmetal' }, { n: 9, s: 'F', name: 'Fluorine', c: 'halogen' }, { n: 10, s: 'Ne', name: 'Neon', c: 'noble' },
    // Row 3
    { n: 11, s: 'Na', name: 'Sodium', c: 'alkali' }, { n: 12, s: 'Mg', name: 'Magnesium', c: 'alkaline-earth' }, ...Array(10).fill({ n: 0 }), { n: 13, s: 'Al', name: 'Aluminium', c: 'post-transition' }, { n: 14, s: 'Si', name: 'Silicon', c: 'metalloid' }, { n: 15, s: 'P', name: 'Phosphorus', c: 'nonmetal' }, { n: 16, s: 'S', name: 'Sulfur', c: 'nonmetal' }, { n: 17, s: 'Cl', name: 'Chlorine', c: 'halogen' }, { n: 18, s: 'Ar', name: 'Argon', c: 'noble' },
    // Row 4
    { n: 19, s: 'K', name: 'Potassium', c: 'alkali' }, { n: 20, s: 'Ca', name: 'Calcium', c: 'alkaline-earth' }, { n: 21, s: 'Sc', name: 'Scandium', c: 'transition' }, { n: 22, s: 'Ti', name: 'Titanium', c: 'transition' }, { n: 23, s: 'V', name: 'Vanadium', c: 'transition' }, { n: 24, s: 'Cr', name: 'Chromium', c: 'transition' }, { n: 25, s: 'Mn', name: 'Manganese', c: 'transition' }, { n: 26, s: 'Fe', name: 'Iron', c: 'transition' }, { n: 27, s: 'Co', name: 'Cobalt', c: 'transition' }, { n: 28, s: 'Ni', name: 'Nickel', c: 'transition' }, { n: 29, s: 'Cu', name: 'Copper', c: 'transition' }, { n: 30, s: 'Zn', name: 'Zinc', c: 'transition' }, { n: 31, s: 'Ga', name: 'Gallium', c: 'post-transition' }, { n: 32, s: 'Ge', name: 'Germanium', c: 'metalloid' }, { n: 33, s: 'As', name: 'Arsenic', c: 'metalloid' }, { n: 34, s: 'Se', name: 'Selenium', c: 'nonmetal' }, { n: 35, s: 'Br', name: 'Bromine', c: 'halogen' }, { n: 36, s: 'Kr', name: 'Krypton', c: 'noble' },
    // Row 5
    { n: 37, s: 'Rb', name: 'Rubidium', c: 'alkali' }, { n: 38, s: 'Sr', name: 'Strontium', c: 'alkaline-earth' }, { n: 39, s: 'Y', name: 'Yttrium', c: 'transition' }, { n: 40, s: 'Zr', name: 'Zirconium', c: 'transition' }, { n: 41, s: 'Nb', name: 'Niobium', c: 'transition' }, { n: 42, s: 'Mo', name: 'Molybdenum', c: 'transition' }, { n: 43, s: 'Tc', name: 'Technetium', c: 'transition' }, { n: 44, s: 'Ru', name: 'Ruthenium', c: 'transition' }, { n: 45, s: 'Rh', name: 'Rhodium', c: 'transition' }, { n: 46, s: 'Pd', name: 'Palladium', c: 'transition' }, { n: 47, s: 'Ag', name: 'Silver', c: 'transition' }, { n: 48, s: 'Cd', name: 'Cadmium', c: 'transition' }, { n: 49, s: 'In', name: 'Indium', c: 'post-transition' }, { n: 50, s: 'Sn', name: 'Tin', c: 'post-transition' }, { n: 51, s: 'Sb', name: 'Antimony', c: 'metalloid' }, { n: 52, s: 'Te', name: 'Tellurium', c: 'metalloid' }, { n: 53, s: 'I', name: 'Iodine', c: 'halogen' }, { n: 54, s: 'Xe', name: 'Xenon', c: 'noble' },
    // Row 6
    { n: 55, s: 'Cs', name: 'Cesium', c: 'alkali' }, { n: 56, s: 'Ba', name: 'Barium', c: 'alkaline-earth' }, { n: 0 }, { n: 72, s: 'Hf', name: 'Hafnium', c: 'transition' }, { n: 73, s: 'Ta', name: 'Tantalum', c: 'transition' }, { n: 74, s: 'W', name: 'Tungsten', c: 'transition' }, { n: 75, s: 'Re', name: 'Rhenium', c: 'transition' }, { n: 76, s: 'Os', name: 'Osmium', c: 'transition' }, { n: 77, s: 'Ir', name: 'Iridium', c: 'transition' }, { n: 78, s: 'Pt', name: 'Platinum', c: 'transition' }, { n: 79, s: 'Au', name: 'Gold', c: 'transition' }, { n: 80, s: 'Hg', name: 'Mercury', c: 'transition' }, { n: 81, s: 'Tl', name: 'Thallium', c: 'post-transition' }, { n: 82, s: 'Pb', name: 'Lead', c: 'post-transition' }, { n: 83, s: 'Bi', name: 'Bismuth', c: 'post-transition' }, { n: 84, s: 'Po', name: 'Polonium', c: 'metalloid' }, { n: 85, s: 'At', name: 'Astatine', c: 'halogen' }, { n: 86, s: 'Rn', name: 'Radon', c: 'noble' },
    // Row 7
    { n: 87, s: 'Fr', name: 'Francium', c: 'alkali' }, { n: 88, s: 'Ra', name: 'Radium', c: 'alkaline-earth' }, { n: 0 }, { n: 104, s: 'Rf', name: 'Rutherfordium', c: 'transition' }, { n: 105, s: 'Db', name: 'Dubnium', c: 'transition' }, { n: 106, s: 'Sg', name: 'Seaborgium', c: 'transition' }, { n: 107, s: 'Bh', name: 'Bohrium', c: 'transition' }, { n: 108, s: 'Hs', name: 'Hassium', c: 'transition' }, { n: 109, s: 'Mt', name: 'Meitnerium', c: 'transition' }, { n: 110, s: 'Ds', name: 'Darmstadtium', c: 'transition' }, { n: 111, s: 'Rg', name: 'Roentgenium', c: 'transition' }, { n: 112, s: 'Cn', name: 'Copernicium', c: 'transition' }, { n: 113, s: 'Nh', name: 'Nihonium', c: 'post-transition' }, { n: 114, s: 'Fl', name: 'Flerovium', c: 'post-transition' }, { n: 115, s: 'Mc', name: 'Moscovium', c: 'post-transition' }, { n: 116, s: 'Lv', name: 'Livermorium', c: 'post-transition' }, { n: 117, s: 'Ts', name: 'Tennessine', c: 'halogen' }, { n: 118, s: 'Og', name: 'Oganesson', c: 'noble' },
    // Row 8 (Lanthanides)
    ...Array(3).fill({ n: 0 }), { n: 57, s: 'La', name: 'Lanthanum', c: 'lanthanide' }, { n: 58, s: 'Ce', name: 'Cerium', c: 'lanthanide' }, { n: 59, s: 'Pr', name: 'Praseodymium', c: 'lanthanide' }, { n: 60, s: 'Nd', name: 'Neodymium', c: 'lanthanide' }, { n: 61, s: 'Pm', name: 'Promethium', c: 'lanthanide' }, { n: 62, s: 'Sm', name: 'Samarium', c: 'lanthanide' }, { n: 63, s: 'Eu', name: 'Europium', c: 'lanthanide' }, { n: 64, s: 'Gd', name: 'Gadolinium', c: 'lanthanide' }, { n: 65, s: 'Tb', name: 'Terbium', c: 'lanthanide' }, { n: 66, s: 'Dy', name: 'Dysprosium', c: 'lanthanide' }, { n: 67, s: 'Ho', name: 'Holmium', c: 'lanthanide' }, { n: 68, s: 'Er', name: 'Erbium', c: 'lanthanide' }, { n: 69, s: 'Tm', name: 'Thulium', c: 'lanthanide' }, { n: 70, s: 'Yb', name: 'Ytterbium', c: 'lanthanide' }, { n: 71, s: 'Lu', name: 'Lutetium', c: 'lanthanide' },
    // Row 9 (Actinides)
    ...Array(3).fill({ n: 0 }), { n: 89, s: 'Ac', name: 'Actinium', c: 'actinide' }, { n: 90, s: 'Th', name: 'Thorium', c: 'actinide' }, { n: 91, s: 'Pa', name: 'Protactinium', c: 'actinide' }, { n: 92, s: 'U', name: 'Uranium', c: 'actinide' }, { n: 93, s: 'Np', name: 'Neptunium', c: 'actinide' }, { n: 94, s: 'Pu', name: 'Plutonium', c: 'actinide' }, { n: 95, s: 'Am', name: 'Americium', c: 'actinide' }, { n: 96, s: 'Cm', name: 'Curium', c: 'actinide' }, { n: 97, s: 'Bk', name: 'Berkelium', c: 'actinide' }, { n: 98, s: 'Cf', name: 'Californium', c: 'actinide' }, { n: 99, s: 'Es', name: 'Einsteinium', c: 'actinide' }, { n: 100, s: 'Fm', name: 'Fermium', c: 'actinide' }, { n: 101, s: 'Md', name: 'Mendelevium', c: 'actinide' }, { n: 102, s: 'No', name: 'Nobelium', c: 'actinide' }, { n: 103, s: 'Lr', name: 'Lawrencium', c: 'actinide' }
];

// Math Tab Logic
const mathTabs = document.getElementById('math-tabs');
// const mathSymbolsGrid = document.getElementById('math-symbols-grid'); // Already declared

// Switch Math Tab
function switchMathTab(category) {
    // Update active tab UI
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.textContent.toLowerCase() === category) btn.classList.add('active');
    });

    // Render symbols
    mathSymbolsGrid.innerHTML = '';
    const symbols = mathSymbols[category] || [];
    symbols.forEach(sym => {
        const btn = document.createElement('div');
        btn.className = 'symbol-btn';
        
        // Use KaTeX to render the label if it's LaTeX-like or has a display property
        // Otherwise just text
        const displayContent = sym.display || sym.label;
        
        // Check if it needs KaTeX rendering (contains backslash or special chars)
        if (displayContent.includes('\\') || displayContent.includes('^') || displayContent.includes('_')) {
             try {
                katex.render(displayContent, btn, { throwOnError: false });
             } catch(e) {
                 btn.textContent = sym.label;
             }
        } else {
            btn.textContent = sym.label;
        }
        
        btn.onclick = () => insertSymbol(sym.code);
        mathSymbolsGrid.appendChild(btn);
    });
}

// Insert Symbol
function insertSymbol(symbol) {
    if (mathModal.style.display === 'block') {
        const start = mathInput.selectionStart;
        const end = mathInput.selectionEnd;
        const text = mathInput.value;
        const before = text.substring(0, start);
        const after = text.substring(end, text.length);
        
        mathInput.value = before + symbol + after;
        mathInput.selectionStart = mathInput.selectionEnd = start + symbol.length;
        mathInput.focus();
        renderMath(mathInput.value);
    } else {
        const doc = cmEditor.getDoc();
        const cursor = doc.getCursor();
        doc.replaceRange(symbol, cursor);
        cmEditor.focus();
    }
}

// Open Math Builder
function openMathBuilder(mode, code) {
    currentMathMode = mode;
    isChemMode = (mode === 'chemistry');
    
    // Update UI
    const titleEl = document.getElementById('math-modal-title');
    if (titleEl) {
        titleEl.textContent = (mode === 'inline' ? 'Inline Math' : (mode === 'display' ? 'Display Math' : 'Equation Builder'));
    }

    const chemCheck = document.getElementById('math-chem-check');
    const blockCheck = document.getElementById('math-block-check');
    
    if (chemCheck) chemCheck.checked = isChemMode;
    if (blockCheck) blockCheck.checked = (mode === 'display');
    
    // Show modal
    mathModal.style.display = 'block';
    
    // Set initial content
    mathInput.value = code ? code : '';
    mathPreview.innerHTML = ''; // Clear preview
    
    // Render initial preview
    if (code) {
        renderMath(code);
    }
}

// Close Math Modal
function closeMathModal() {
    mathModal.style.display = 'none';
}

// Render Math
function renderMath(code) {
    // Clear previous
    mathPreview.innerHTML = '';
    
    if (!code || !code.trim()) return;

    if (typeof katex === 'undefined') {
        mathPreview.innerHTML = '<span style="color:red">KaTeX not loaded</span>';
        return;
    }
    
    // Determine if display mode
    const isDisplay = currentMathMode === 'display' || code.trim().startsWith('$$');
    
    // Render with KaTeX
    try {
        // Remove delimiters for rendering if present, as katex.render expects raw latex
        let cleanCode = code;
        if (cleanCode.startsWith('$$') && cleanCode.endsWith('$$')) {
            cleanCode = cleanCode.substring(2, cleanCode.length - 2);
        } else if (cleanCode.startsWith('$') && cleanCode.endsWith('$')) {
            cleanCode = cleanCode.substring(1, cleanCode.length - 1);
        }

        katex.render(cleanCode, mathPreview, {
            throwOnError: false,
            displayMode: isDisplay
        });
    } catch (e) {
        console.error("Math rendering error:", e);
        mathPreview.innerHTML = `<span style="color:red; font-size:12px">Error: ${e.message}</span>`;
    }
}

// Insert Math Template
function insertMathTemplate(template) {
    const code = templates.math.find(t => t.id === template).code;
    insertTemplateCode(code);
    closeTemplateModal();
}

// Open Periodic Table
function openPeriodicTable() {
    periodicTableContainer.style.display = 'block';
    periodicTableGrid.innerHTML = ''; // Clear previous
    
    // Create grid
    const rows = 9;
    const cols = 18;
    for (let r = 0; r < rows; r++) {
        const row = document.createElement('div');
        row.className = 'periodic-table-row';
        for (let c = 0; c < cols; c++) {
            const index = r * cols + c;
            const element = periodicTableData[index];
            const cell = document.createElement('div');
            cell.className = 'periodic-table-cell';
            
            if (element && element.n) {
                cell.innerHTML = `<span class="element-symbol">${element.s}</span><br><span class="element-name">${element.name}</span>`;
                if (element.c) {
                    cell.classList.add(element.c);
                }
                cell.onclick = () => insertElementToEditor(element);
            } else {
                cell.classList.add('empty');
            }
            
            row.appendChild(cell);
        }
        periodicTableGrid.appendChild(row);
    }
}

// Close Periodic Table
function closePeriodicTable() {
    periodicTableContainer.style.display = 'none';
}

// Insert Element to Editor
function insertElementToEditor(element) {
    const elementCode = `\\ce{${element.s}}`;
    
    if (mathModal.style.display === 'block') {
        const start = mathInput.selectionStart;
        const end = mathInput.selectionEnd;
        const text = mathInput.value;
        const before = text.substring(0, start);
        const after = text.substring(end, text.length);
        
        mathInput.value = before + elementCode + after;
        mathInput.selectionStart = mathInput.selectionEnd = start + elementCode.length;
        mathInput.focus();
        renderMath(mathInput.value);
    } else {
        const doc = cmEditor.getDoc();
        const cursor = doc.getCursor();
        doc.replaceRange(`$${elementCode}$`, cursor);
        cmEditor.focus();
    }
    closePeriodicTable();
}

// Toggle Periodic Table
function togglePeriodicTable() {
    if (periodicTableContainer.style.display === 'block') {
        closePeriodicTable();
    } else {
        openPeriodicTable();
    }
}

// Insert Math From Builder
function insertMathFromBuilder() {
    let code = mathInput.value;
    if (!code) {
        closeMathModal();
        return;
    }

    let isBlock = false;

    // Wrap based on mode
    if (isChemMode) {
        if (!code.includes('\\ce{')) {
            code = `\\ce{${code}}`;
        }
        code = `$${code}$`; 
    } else if (currentMathMode === 'display' || mathBlockCheck.checked) {
        code = `$$\n${code}\n$$`;
        isBlock = true;
    } else {
        code = `$${code}$`;
    }

    if (isBlock) {
        insertTemplateCode(code);
    } else {
        const doc = cmEditor.getDoc();
        const cursor = doc.getCursor();
        doc.replaceRange(code, cursor);
        render();
        cmEditor.focus();
    }
    
    closeMathModal();
}

// Event Listeners for Math Builder
if (mathInput) {
    mathInput.addEventListener('input', () => {
        renderMath(mathInput.value);
    });
}

// Context Menu Logic
const contextMenu = document.getElementById('context-menu');

document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const { clientX: mouseX, clientY: mouseY } = e;

    // Adjust position if close to edge
    let top = mouseY;
    let left = mouseX;
    
    if (contextMenu) {
        contextMenu.style.top = `${top}px`;
        contextMenu.style.left = `${left}px`;
        contextMenu.style.display = 'block';
    }
});

document.addEventListener('click', (e) => {
    if (contextMenu && e.target.offsetParent !== contextMenu) {
        contextMenu.style.display = 'none';
    }
});

// Close context menu on Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && contextMenu) {
        contextMenu.style.display = 'none';
    }
});

if (mathBlockCheck) {
    mathBlockCheck.addEventListener('change', () => {
        currentMathMode = mathBlockCheck.checked ? 'display' : 'inline';
        renderMath(mathInput.value);
    });
}

if (mathChemCheck) {
    mathChemCheck.addEventListener('change', () => {
        isChemMode = mathChemCheck.checked;
        if (isChemMode) {
            switchMathTab('chemistry');
        }
        renderMath(mathInput.value);
    });
}
